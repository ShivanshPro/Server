<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');

$LANG = array();
$LANG['gobackbtn'] = 'Go back';
$LANG['gobacktobtn'] = 'Go back to start';
$LANG['gobacktohbtn'] = 'Go back to home';
$LANG['homedes'] = 'Scan your account for unused or forgotten files<br>Run a scan and you will know that within seconds how much disk space you can clean up.';
$LANG['defaultscandes'] = 'The default scan is for error_log, *.zip, *.tar, *.tar.gz files and /tmp, /.trash folders.';
$LANG['homebtn'] = 'Start New Scan';
$LANG['scandes'] = 'The scan results for files and folders under your account that suspected as garbage,<br>Before you click on "Clean Files" uncheck the files you do not want to delete!.';
$LANG['scanth1'] = 'Searching files';
$LANG['scanth2'] = 'Total Size (MB)';
$LANG['scanth3'] = 'Total Disk Usage';
$LANG['diskusage'] = 'Disk Usage';
$LANG['scanbtn'] = 'Clean Files';
$LANG['submitconfirm1'] = 'After cleaning the files you will not have the possibility to recover!';
$LANG['submitconfirm2'] = 'Are you sure you want to continue?';
$LANG['cleantot'] = 'Total';
$LANG['cleantot2'] = 'files have been cleared';

?>