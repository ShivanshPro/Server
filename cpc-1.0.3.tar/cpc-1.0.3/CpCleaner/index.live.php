<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');


##################################################
#                                                #
# GK~root - Creating a better web                #
# Copyright (c) GK~root. All Rights Reserved.    #
# Software: CpCleaner                            #
# Version: 1.0.3                                 #
# Create Date: Sep 24 2017                       #
# Website: http://www.gk-root.com                #
#                                                #
##################################################
#                                                #
# This software is released under a license.     #
# You cannot transfer it to any other person,    #
# resell it or claim any code as your own.       #
# By using the software you agree to this terms. #
#                                                #
##################################################

// Include CPPHP
require_once("inc/conf.inc.php");

// Set user language
include(SetLang());

// cPanel Header
cpHeader();

$Desped='';
if (UserTheme() == 'x3') {
	echo '<div style="padding-left:20px;" class="h1Title"><img src="img/icon-x3.jpg" alt="" /> CpCleaner</div>';
	$Desped = 'style="padding-left:10px;"';
}

// Main content
if (empty($action)) {
    echo '
    <p '.$Desped.' id="descMysql" class="description">
        '.$LANG['homedes'].'
    </p>
    <p>'.$LANG['defaultscandes'].'</p>
    <br><br>
    <form action="index.live.php?action=scan" method="post" style="width: 100%;">
    	<div style="width: 250px; height:70px; margin: 0 auto;">
    		<input class="cpcprimary" value="'.$LANG['homebtn'].'" type="submit" style="width: 250px; height:70px; font-size: 28px;">
    	</div>
    </form>
    ';
    GoBackBtn('tohome');
} elseif ($action == 'scan') {
	include($CROOTDIR."inc/scan.live.php");
	GoBackBtn('');
} elseif ($action == 'clean') {
	include($CROOTDIR."inc/clean.live.php");
	GoBackBtn('tostart');
}

// cPanel Footer
cpFooter();
?>