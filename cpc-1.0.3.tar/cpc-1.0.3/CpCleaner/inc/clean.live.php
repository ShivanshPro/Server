<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');


##################################################
#                                                #
# GK~root - Creating a better web                #
# Copyright (c) GK~root. All Rights Reserved.    #
# Software: CpCleaner                            #
# Version: 1.0.3                                 #
# Create Date: Sep 24 2017                       #
# Website: http://www.gk-root.com                #
#                                                #
##################################################
#                                                #
# This software is released under a license.     #
# You cannot transfer it to any other person,    #
# resell it or claim any code as your own.       #
# By using the software you agree to this terms. #
#                                                #
##################################################

echo '
<style type="text/css">
    #progressBar {
        width: 900px;
        height: 22px;
        border: 1px solid #111;
        background-color: #292929;
        margin: 0 auto;
    }
    #progressBar div {
        height: 100%;
        color: #fff;
        text-align: right;
        line-height: 22px;
        width: 0;
        background-color: #0099ff;
    }
	.default {
		background: #292929;
		border: 1px solid #111;	
		border-radius: 5px;	
		overflow: hidden;
		box-shadow: 0 0 5px #333;				
	}
	.default div {
		background-color: #1a82f7;
		background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#0099FF), to(#1a82f7)); 
		background: -webkit-linear-gradient(top, #0099FF, #1a82f7); 
		background: -moz-linear-gradient(top, #0099FF, #1a82f7); 
		background: -ms-linear-gradient(top, #0099FF, #1a82f7); 
		background: -o-linear-gradient(top, #0099FF, #1a82f7);
	}
</style>
<script type="text/javascript">
    function progress(percent, $element) {
        var progressBarWidth = percent * $element.width() / 100;
        $element.find(\'div\').animate({ width: progressBarWidth }, 500).html(" "+percent+"% ");
    }
	function RunProgressBar(i) {
		setTimeout(function(){ 
			progress(i, $("#progressBar"));
		}, i * 500);
	}
	for(var i=0; i < 91; i++) {
		RunProgressBar(i);
	}
</script>
<div id="progressBar" class="default"><div></div></div><br>';
$i=0;
sleep(3);
foreach ($_POST['filestoclean'] as $tfile=>$val) {
	$tfile = trim($tfile);
	if ($tfile == 'tmp') {
		if (!RemoveTmpFolderContent()) {
			echo '<p>Error delete tmp content</p>';
			$tmpcc = true;
		} else {
			$tmpcc = ' + tmp folder';
		}
	} elseif ($tfile == '.trash') {
		if (!RemoveTrashFolderContent()) {
			echo '<p>Error delete .trash content</p>';
			$trashcc = '';
		} else {
			$trashcc = ' + trash folder';
		}
	} else {	
		if (!unlink(getenv('HOME').$tfile)) {
			echo '<p>Error delete file: '.$tfile.'</p>';
		} else {
			$i++;
		}
	}
}
sleep(1);
echo '<script type="text/javascript">
	progress(100, $("#progressBar"));
</script>';
sleep(1);
echo '<script type="text/javascript">
	$("#progressBar").html(\'<p style="text-align:center;color:#fff;">'.$LANG['cleantot'].' '.$i.' '.$LANG['cleantot2'].' '.$tmpcc.$trashcc.'</p>\');
</script>';

?>