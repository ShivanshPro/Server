<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');


##################################################
#                                                #
# GK~root - Creating a better web                #
# Copyright (c) GK~root. All Rights Reserved.    #
# Software: CpCleaner                            #
# Version: 1.0.3                                 #
# Create Date: Sep 24 2017                       #
# Website: http://www.gk-root.com                #
#                                                #
##################################################
#                                                #
# This software is released under a license.     #
# You cannot transfer it to any other person,    #
# resell it or claim any code as your own.       #
# By using the software you agree to this terms. #
#                                                #
##################################################

$CROOTDIR = '/usr/local/cpanel/base/3rdparty/CpCleaner/';
require_once("/usr/local/cpanel/php/cpanel.php");
$livecpapi = new CPANEL();
require_once($CROOTDIR.'inc/func.inc.php');
if (isset($_GET['action'])) {$action = trim($_GET['action']);} else {$action = '';}
PHP_CONF();
?>