﻿<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');


##################################################
#                                                #
# GK~root - Creating a better web                #
# Copyright (c) GK~root. All Rights Reserved.    #
# Software: CpCleaner                            #
# Version: 1.0.3                                 #
# Create Date: Sep 24 2017                       #
# Website: http://www.gk-root.com                #
#                                                #
##################################################
#                                                #
# This software is released under a license.     #
# You cannot transfer it to any other person,    #
# resell it or claim any code as your own.       #
# By using the software you agree to this terms. #
#                                                #
##################################################

// Include CPPHP
require_once("inc/conf.inc.php");
$UserTheme 	= UserTheme();
$x3table = '';
$x3p = '';

// Start scan by filesforscanned conf
$StartScan = StartScan();
$TrashFoldersize = folderSize(getenv('HOME').'/.trash');
$TrashPercentage = QuotaUsePercentage($TrashFoldersize);
$TmpFoldersize = folderSize(getenv('HOME').'/tmp');
$TmpPercentage = QuotaUsePercentage($TmpFoldersize);

			
// Scan output
if ($UserTheme != 'paper_lantern') {
	echo '
	<style type="text/css">
	.usage-bar{width:450px;float:left;padding-left:2px;padding-top:1.5px;padding-right:2px;overflow:hidden;margin:0;height:30px}
	.usage-bar-with-note{width:450px;float:left;padding-left:10px;padding-top:1.5px;padding-right:10px;border-left:1px solid #fff;overflow:hidden;margin:0;height:40px}
	.usage-note{padding-left:5px;padding-right:5px}
	.usage-background{background:url(/frontend/x3/images/filler-bg2.png) repeat-x;border-radius:20px;-moz-border-radius:20px;border:1px solid #d5d5d5;padding:5px 3px 3px 5px;overflow:hidden}
	.filler-bg{border-radius:20px;-moz-border-radius:20px;height:15px;width:315px;overflow:hidden;float:left}
	.graph-bar{background:url(/frontend/x3/images/images/filler.png) repeat-x; background: blue; text-align:center; color:#fff; height:14px;width:35%;border-radius:20px;-moz-border-radius:20px;-webkit-border-radius:20px;overflow:hidden;border-bottom:1px solid #fff}
	</style>';
	$x3table = 'style="width:720px;padding:15px;"';
	$x3p = 'style="padding:15px;"';
}

echo '

<p id="descMysql" class="description" '.$x3p.'>
    '.$LANG['scandes'].'
</p>
<form name="cpcf" action="index.live.php?action=clean" method="post" onsubmit="return confirm(\''.$LANG['submitconfirm1'].'\n'.$LANG['submitconfirm2'].'\');">
	<table id="usage-table" class="table table-condensed usage-table" '.$x3table.'>
		<thead>
			<tr>
				<th id="lblTableLocation">'.$LANG['scanth1'].'</th>
				<th id="lblTableSize">'.$LANG['scanth2'].'</th>
				<th id="lblTableDiskUsage">'.$LANG['scanth3'].'</th>
			</tr>
		</thead>
		<tbody id="usage-table-body">';
			if ($StartScan !== false) {
				$i=0;
				foreach ($StartScan as $filename=>$fileres) {
					$filenamec = str_replace(".", "", $filename);
					$filenamec = str_replace("*", "", $filenamec);
					$inputname='checkall'.$filenamec;
					echo '
					<script type="text/javascript">
						$(document).ready(function(){		    
							$("#'.$inputname.'").click(function() {
								if ($(this).is(\':checked\')) {
									$(\'.'.$inputname.'\').each(function() {
										$(this).prop("checked", true);
									});
								} else {
									$(\'.'.$inputname.'\').each(function() {
										$(this).prop("checked", false);
									});
								}
							});
						});
					</script>
					<tr>
						<td class="directory" style="background-color: #ccc"><strong><input type="checkbox"  checked="checked" value="cleanall'.$filename.'" id="'.$inputname.'" /> ('.$fileres['numfiles'].')</strong> '.$filename.'</td>
						<td class="percentage" style="background-color: #ccc">'.$fileres['totalsizeclean'].'</td>
						<td class="usage-bar" style="background-color: #ccc">';
						if ($UserTheme == 'paper_lantern') {
        					echo'<div class="progress"><div title="'.$fileres['percentagediskusage'].'% '.$LANG['diskusage'].'" class="progress-bar" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: '.$fileres['percentagediskusage'].'%;">'.$fileres['percentagediskusage'].'%</div></div>';
        				} else {
							echo '<div class="usage-bar"><div class="usage-background group"><div class="filler-bg"><div class="graph-bar" style="width: '.$fileres['percentagediskusage'].'%">'.$fileres['percentagediskusage'].'%</div></div></div></div>';
						}
					echo '</td></tr>';
					foreach ($fileres['fileslist'] as $filename=>$filesize) {
						echo '<tr style="font-size: 12px;padding: 2px;"><td colspan="3" style="font-size: 12px;padding: 2px;"><input class="'.$inputname.'" type="checkbox" checked="checked" value="clean" name="filestoclean['.$filename.']" /> '.$filename.' = '.cReturnSizeUnit($filesize).'</td></tr>';
					}
					$i++;
				}
				echo '
					<tr>
						<td class="directory" style="background-color: #ccc"><input type="checkbox" checked="checked" value="clean" name="filestoclean[.trash]" /> /.trash</td>
						<td class="percentage" style="background-color: #ccc">'.cReturnSizeUnit($TrashFoldersize).'</td>
						<td class="usage-bar" style="background-color: #ccc">';
						if ($UserTheme == 'paper_lantern') {
							echo '<div class="progress"><div title="'.$TrashPercentage.'% '.$LANG['diskusage'].'" class="progress-bar" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: '.$TrashPercentage.'%;">'.$TrashPercentage.'%</div></div>';
        				} else {
							echo '<div class="usage-bar"><div class="usage-background group"><div class="filler-bg"><div class="graph-bar" style="width: '.$TrashPercentage.'%">'.$TrashPercentage.'%</div></div></div></div>';
						}
						echo '</td>
					</tr>
					<tr>
						<td class="directory" style="background-color: #ccc"><input type="checkbox" checked="checked" value="clean" name="filestoclean[tmp]" /> /tmp</td>
						<td class="percentage" style="background-color: #ccc">'.cReturnSizeUnit($TmpFoldersize).'</td>
						<td class="usage-bar" style="background-color: #ccc">';
						if ($UserTheme == 'paper_lantern') {
							echo '<div class="progress">
								<div title="'.$TmpPercentage.'% '.$LANG['diskusage'].'" class="progress-bar" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: '.$TmpPercentage.'%;">'.$TmpPercentage.'%</div></div>';
        				} else {
							echo '<div class="usage-bar"><div class="usage-background group"><div class="filler-bg"><div class="graph-bar" style="width: '.$TmpPercentage.'%">'.$TmpPercentage.'%</div></div></div></div>';
        				}
						echo '</td>
					</tr>
				';
			}
		echo '</tbody>
	</table>
   	<div style="width: 250px; height:70px; margin: 0 auto;">
   		<input class="cpcprimary" value="'.$LANG['scanbtn'].'" type="submit" style="width: 250px; height:70px; font-size: 28px;">
   	</div>
</form>';

?>